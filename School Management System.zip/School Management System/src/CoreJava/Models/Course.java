//Richard Soto
//April 13, 2018

package CoreJava.Models;

public class Course  {

    private String courseID;   //Unique Course Identifier (ex: CIS101)
    private String courseName;  //Provides the name of the course
    private String instructor; //Provides the name of the instructor

    public Course (){
        this.courseID ="";
        this.courseName="";
        this.instructor="";
    }
    public Course (String courseID, String courseName, String instructorName){
        this.courseID= courseID;
        this.courseName= courseName;
        this.instructor = instructor;
    }


    public void setCourseID(String courseID){
        this.courseID=courseID;

    }

    public String getCourseID(){
        return this.courseID;

    }

    public void setCourseName(String courseName){
        this.courseName = courseName;

    }

    public String getCourseName(){
        return this.courseName;

    }

    public void setInstructor(String instructor){
        this.instructor=instructor;

    }

    public String getInstructor(){
        return this.instructor;

    }

}
