//Richard Soto
//April 13, 2018

package CoreJava.Models;

public class Student {
    private String email; //provides Student email
    private String name;  //provides Student name
    private String pass;  //provide Student current email


    public Student() {
        this.email="";
        this.name="";
        this.pass="";
    }
    public Student (String email, String name, String pass){
        this.email=email;
        this.name=name;
        this.pass=pass;
    }


    public void setEmail(String email){
       this.email=email;
    }

    public String getEmail(){


        return this.email;


    }

    public void setName(String name){
        this.name=name;
    }

    public String getName(){
        return this.name;

    }

    public void setPass(String pass){
        this.pass=pass;


    }

    public String getPass(){
        return this.pass;

    }
}
