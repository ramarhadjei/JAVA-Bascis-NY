//Richard Soto
//April 13, 2018

package CoreJava.Models;


public class Attending {

    private String courseID;   // Unique Course Identifier (ex: CIS101)
    private String email;      // Student’s current school email


    public Attending (){
        this.courseID="";
        this.email="";
    }
    public Attending (String courseId, String email){
        this.courseID= courseID;
        this.email= email;
    }


    public void setCourseID(String courseID){
        this.courseID= courseID;


    }

    public String getCourseID(){
        return this.courseID;

    }

    public void setEmail(String email){
        this.email=email;

    }

    public String getEmail(){
        return this.email;

    }
}
