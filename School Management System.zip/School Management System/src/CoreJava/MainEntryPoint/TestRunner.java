package CoreJava.MainEntryPoint;
import CoreJava.DAO.AttendingDAO;
import CoreJava.DAO.CourseDAO;
import CoreJava.DAO.StudentDAO;
import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;
import java.util.ArrayList;
import java.util.List;

public class TestRunner {


    public static void main(String[] args) throws Exception {

        StudentDAOTest();

        //CourseDAOTest();

      // AttendingDAOTest();

    }

    public static void StudentDAOTest() throws Exception {

        StudentDAO myStudent = new StudentDAO();
        Student testStudent = new Student();
        List<Student> allTheStudents = new ArrayList<Student>();

        // Read the students from the file and store in allTheStudents
        allTheStudents = myStudent.getStudents();

        System.out.printf("%-5s|%-25s|%-25s|%-25s", "#", "NAME", "EMAIL", "PASSWORD \n");
        System.out.println("_______________________________________________________________");

        for (int i = 0; i < allTheStudents.size(); i++) {
            testStudent = allTheStudents.get(i);
            System.out.printf("%-5s|%-25s|%-25s|%-25s \n\n", (i + 1), testStudent.getName(), testStudent.getEmail(), testStudent.getPass());

        }

        StudentDAO testStudentDAO = new StudentDAO();

        System.out.println ("******(Validating PassWord*****");
        System.out.println(testStudentDAO.validateUser(allTheStudents,
                "tom@gmail.com", "tw2021"));
    }

    public static void CourseDAOTest() throws Exception {
        CourseDAO myCourse = new CourseDAO();
        Course testCourse = new Course();
        List<Course> allTheCourses = new ArrayList<Course>();

        // Read the students from the file and store in allTheStudents
        allTheCourses = myCourse.getAllCourses();

        System.out.println("");
        System.out.printf("%-5s|%-25s|%-25s|%-25s", "#", "CourseID", "CourseName", "Instructor \n");
        System.out.println("_______________________________________________________________");

        for (int i = 0; i < allTheCourses.size(); i++) {
            testCourse = allTheCourses.get(i);
            System.out.printf("%-5s|%-25s|%-25s|%-25s \n\n", (i + 1), testCourse.getCourseID(),
                    testCourse.getCourseName(), testCourse.getInstructor());

        }
    }

    public static void AttendingDAOTest() throws Exception {

        AttendingDAO myAttending = new AttendingDAO();
        Attending testAttending = new Attending();
        List<Attending> allTheAttending = new ArrayList<Attending>();

        // Read the students from the file and store in allTheStudents
        allTheAttending = myAttending.getAttending();

        System.out.printf("%-5s|%-25s|%-25s", "#", "Course ID", "EMAIL   \n");
        System.out.println("_______________________________________________________________");

        for (int i = 0; i < allTheAttending.size(); i++) {
            testAttending = allTheAttending.get(i);
            System.out.printf("%-5s|%-25s|%-25s \n\n", (i + 1), testAttending.getCourseID(), testAttending.getEmail());

        }
        AttendingDAO testAttendingDAO = new AttendingDAO();

        System.out.println ("******(Student Registered to Course AttendingDAO*****");
       // System.out.println(testAttendingDAO.isTheStudentAttending (allTheAttending,
       //         "tom@gmail.com", "tw2021"));

        System.out.println( );
    }


}

