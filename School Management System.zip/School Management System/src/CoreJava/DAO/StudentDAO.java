//Richard Soto
//April 13, 2018


package CoreJava.DAO;

import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDAO {

//getStudents -
    //This method reads the Students.csv file and returns the data as a List<Student>
    //step 1 - Create a File Object
    //Step 2- We read the file
    //Step 3 - We Create a student object pre line
    //Step 4 - We add students to the List Collection
    //Step 5 - We return the list

    public List<Student> getStudents() throws Exception {


        String location = "/Users/soto0123/finalprojectdata/students.csv";
        ArrayList<Student> allTheStudents = new ArrayList<Student>();
        Scanner input = null;

        try {
            // Step 1 - Create a File Object
            File studentsFile = new File(location);
            input = new Scanner(studentsFile);
        } catch (FileNotFoundException e) {
            System.out.println("Error reading file");
        }
        // Step 2 - We read the file
        while (input.hasNextLine()) {
            String line = input.nextLine();
            // Step 3 - We create a studnet object per line
            Student theStudent = new Student(); //hold the student here

            String[] data = line.split(",");

            theStudent.setEmail(data[0]);
            theStudent.setName(data[1]);
            theStudent.setPass(data[2]);

            // Step 4- We add students to the list collection
            allTheStudents.add(theStudent); //store all the students in the arraylist


        }

        // Step 5- We return the list
        return allTheStudents;

    }

    public Student getStudentByEmail(List<Student> studentList, String studentEmail) {
        //getStudentByEmail – This method takes a Student’s email as a String and the List of
        // Students as an ArrayList and parses the List for a Student with that email and
        // returns a Student Object.
        // Step 1 - Loop on the List of Students
        //Step 2 - If the email is found
        //Step 3 - Return the Student exactly where the name matches the Student


        Student thisStudent = new Student();

        //for (int i=0;i<studentList.size();i++) {
        for (Student s : studentList) {


            if (s.getEmail().equalsIgnoreCase(studentEmail)) {
                thisStudent = s;
                break;
            }

        }

        return thisStudent;

    }

    public boolean validateUser(List<Student> studentList, String studentEmail, String studentPass) {

        //validateUser – This method takes the List of Students and two
        // other parameters: the first one is the user email and the second
        // one is the password from the user input. Return whether or not
        // student email and password match

        //Option A - Slow
        //Step 1- Loop on the list of Students
        // 2 - If both email and pass are the same - return true
        // 3 - If the for loop ends without finding a match -- return false

        // OPTION 2 - Fast
        // 1- Invoke method getStudentByEmail(List<Student> studentList, String studentEmail)
        // 2- Get the returned student object and compare its password to the provided password


        //for (int i=0;i<studentList.size();i++) {
        for (Student s : studentList) {

            //if (studentList.get(i).getEmail().equalsIgnoreCase(studentEmail)){
            //thisStudent=studentList.get(i);
            if (s.getEmail().equalsIgnoreCase(studentEmail)
                    && s.getPass().equalsIgnoreCase(studentPass)) {

                return true;

            }

        }

        return false;

    }


}
