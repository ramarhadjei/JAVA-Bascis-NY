//Richard Soto
//April 13, 2018

//1	List<Attending>	AttendingDAO	getAttending –
//This method reads the Attending.csv file and returns the data as a List<Attending>	None

//2	void	AttendingDAO	registerStudentToCourse – This method takes a Student’s email and a Course ID.
// It checks if a Student with that Email is currently attending a Course with that ID.
//If the Student is not attending that Course, add a new Attending object with the Student’s Email and
// Course ID to the List.	List<Attending> attending,
//String student_email,String course_id

//3	List<Course>	AttendingDAO	getStudentCourse –
//This method takes a Student’s Email as a parameter and would search the Attending List for all the
// courses a student is registered to base on the Id.
//Each of these is added to a new List of courses. This list of courses the Student is attending is returned
// List<Attending> attending,String studentEmail

//4	Void	AttendingDAO	saveAttending –
//This method overwrites the original Attending.csv file with the new data	List<Attending> attending

package CoreJava.DAO;

import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.File;


public class AttendingDAO {

    public List<Attending> getAttending() throws Exception {

        String location = "/Users/soto0123/finalprojectdata/attending.csv";
        ArrayList<Attending> allTheAttending = new ArrayList<Attending>();
        try {
            File attendingFile = new File(location);
            Scanner input = new Scanner(attendingFile);

            while (input.hasNextLine()) {
                String line = input.next();
                Attending theAttending = new Attending(); //hold the course here

                String[] data = line.split(",");

                theAttending.setCourseID(data[0]);
                theAttending.setEmail(data[1]);

                allTheAttending.add(theAttending); //adds the attending in the arraylist
            }
        } catch (Exception e) {
            System.out.println("Error reading file");
        }
        return allTheAttending;
    }


    public void registerStudentToCourse(List<Attending> attendingList, String studentEmail, String courseID)
            throws Exception {
//        Attending attendance = new Attending();
//        attendance.setCourseID(courseID);
//        attendance.setEmail(studentEmail);
//        attendingList.add(attendance);
//
//        saveAttending(attendingList);
//    }

        boolean isTheStudentAttending = false;
        Attending newStudent = new Attending();

        for (Attending a : attendingList) {

            if ((a.getEmail().equalsIgnoreCase(studentEmail) &&
                    a.getCourseID().equalsIgnoreCase(courseID))) {

                isTheStudentAttending = true;
                break;

            }

        }
            if (isTheStudentAttending == false) {
                newStudent.setCourseID(courseID);
                newStudent.setEmail(studentEmail);

                attendingList.add(newStudent);
                saveAttending(attendingList);
            }


    }




//     3	List<Course>	AttendingDAO	getStudentCourse –
//     This method takes a Student’s Email as a parameter and would search the Attending List for all the
//      courses a student is registered to base on the Id.
//     Each of these is added to a new List of courses. This list of courses the Student is attending is returned
//      List<Attending> attending, String studentEmail


    public List<Course> getStudentCourses(List<Course> courseList, List<Attending> attending,
                                          String studentEmail) {


        List<Course> studentCourseList = new ArrayList<Course>();

        for (Attending a:attending)  {

            if (a.getEmail().equalsIgnoreCase(studentEmail)) {  //match the student

            for (Course c:courseList){//loop thru al the provided courses
                if (c.getCourseID().equals(a.getCourseID()))  { //match course in the attendance
                    Course studentCourse = new Course(a.getCourseID(), " ", "");
                    studentCourse.setCourseName(c.getCourseName());//get the course name
                    studentCourse.setInstructor(c.getInstructor());//get the instructor
                    studentCourseList.add(studentCourse); //add course to the collection
                }
            }

            }

        }

                return studentCourseList; //passes data to main runner

    }
    public void saveAttending (List < Attending > attending) throws Exception {
            String location = "/Users/soto0123/finalprojectdata/attending.csv";
            try {
                File file = new File(location);
                FileWriter writer = new FileWriter(file, false);
                BufferedWriter bwriter = new BufferedWriter(writer);

                for (Attending a : attending) {
                    bwriter.write(a.getCourseID() + ","
                            + a.getEmail());
                    bwriter.newLine();
                }
                bwriter.close();
                writer.close();

            }
            catch(FileNotFoundException e){
                System.out.println("File Not Found");
            }



    }
}