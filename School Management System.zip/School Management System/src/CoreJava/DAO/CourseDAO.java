//Richard Soto
//April 13, 2018
//No. 1.	Return Type	Class Name	Method Name	Input Parameters
// 	List<Course>	CourseDAO	getAllCourses – This method takes no
// parameter and returns every Course in the table.	None


package CoreJava.DAO;

import CoreJava.Models.Course;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourseDAO {

    public List<Course> getAllCourses() throws Exception {


        String location = "/Users/soto0123/finalprojectdata/courses.csv";
        ArrayList<Course> allTheCourses = new ArrayList<Course>();
        try {
            File coursesFile = new File(location);
            Scanner input = new Scanner(coursesFile);

            while (input.hasNextLine()) {
                String line = input.next();
                Course theCourse = new Course(); //hold the course here

                String[] data = line.split(",");

                theCourse.setCourseID(data[0]);
                theCourse.setCourseName(data[1]);
                theCourse.setInstructor(data[2]);
                allTheCourses.add(theCourse); //store all the courses in the arraylist
            }
        }
        catch (FileNotFoundException e){
            System.out.println("Error reading file");
        }
            return allTheCourses;
        }




}

